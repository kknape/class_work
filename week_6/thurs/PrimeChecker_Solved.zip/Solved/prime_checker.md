# Prime Checker

## Instructions

Write a function that checks to see if a number is a prime number or not. Have it return `true` if it is, or `false` if it isn't.

## More Info

A Prime number is a number greater than one that can only be divided by one and itself.

[More info on Prime numbers](https://www.mathsisfun.com/prime_numbers.html)

#### Video Solution

Link: <https://youtu.be/VCpdZ1AL17I>
